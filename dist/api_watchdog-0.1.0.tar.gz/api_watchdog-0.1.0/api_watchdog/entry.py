from api_watchdog.utils.api_fetcher import fetch_api
from api_watchdog.utils.logger import get_logger
import time
from api_watchdog.cli import parse_args


def run():
    args = parse_args()
    api_class = args.api
    log = get_logger(log_file=args.log_file)

    log.info("fetching api")
    api_var = api_class.var

    api = api_class(
        logger=log,
        argument=getattr(args, api_var),
        interval=args.interval,
        log_file=args.log_file,
    )

    api_url, interval, _ = api.get_config()
    api_data = fetch_api(api_url)
    api.configuration(api_data)
    log.info("api fetched")

    time.sleep(interval)
    run()


if __name__ == "__main__":
    run()
